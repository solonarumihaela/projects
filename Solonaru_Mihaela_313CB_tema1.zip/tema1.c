//SOLONARU Mihaela-313CB
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// functia hash
unsigned long hashFunction(char* str, int M) {
    unsigned long i = 0;
    for (int j=0; str[j]; j++)
        i += str[j];
    return i % M;
}

// nodul din lista dublu inlantuita circulara
typedef struct HTNode {
    char* key; // adresa url
    char* value; // adresa ip
    struct HTNode *next;
    struct HTNode *prev;
}HTNode;

// tabela hash
typedef struct HashTable {
    HTNode** lists; // vectorul de noduri (liste)
    int size; // dimensiunea tabelei (M)
}HashTable;

// functia creeaza  si returneaza o tabela hash
HashTable* createHashTable(int size) {
    // aloc memorie si initializez campurile tabelei
    HashTable* table = malloc(sizeof(HashTable));
    table->lists = malloc(size*sizeof(HTNode*));
    // initial toate listele sunt vide
    table->size = size;
    for (int i = 0; i < table->size; i++)
        table->lists[i] = NULL;
    // returnez tabela creata
    return table;
}

// functia creeaza si returneaza un nod cu key si value
HTNode* createHTNode(char* key, char* value) {
    // alocam memorie pentru nod si campurile key si value
    HTNode* node = (HTNode*)malloc(sizeof(HTNode));
    node->key = (char*)malloc(strlen(key) + 1);
    node->value = (char*)malloc(strlen(value) + 1);
    // initializam campurile key si value
    strcpy(node->key, key);
    strcpy(node->value, value);
    // initial nu are legaturi si ca e circulara poiteaza la el isusi
    node->next = node;
    node->prev = node;
 	// returnam nodul creat
    return node;
}

// Functia cauta nodul cu "key" in tabela hash (returneaza 1 -True/ 0 -False)
int find(HashTable *table, char *key) {
	// aflu indexul listei
	int index = hashFunction(key, table->size);
	HTNode *curr = table->lists[index];
	// verific daca lista e vida
	if (curr == NULL)
		return 0;
	// parcurg lista verificand daca key apartine listei
	while(curr->next != table->lists[index]) {
		if (strcmp(curr->key, key) == 0) {
			return 1;
		}
		curr = curr->next;
	}
	// verificam ultimul nod
	if (strcmp(curr->key, key) == 0) {
			return 1;
	}
	// returnam NULL daca nu s-a gasit
	return 0;
}

// functia insereaza nodul "node" in lista "list"
void insertInList(HTNode **list, HTNode *node) {

	// 1 caz : cand lista e vida
	if(*list == NULL) {
		*list = node;
		return;
	}

	HTNode *curr = *list;
	
	// 2 caz : inserare in fata
	if (strcmp(node->key, (*list)->key) < 0) {
		curr->prev->next = node;
		node->prev = curr->prev;
		curr->prev = node;
		node->next = curr;
		*list = node;
		return;
	}

	// 3 caz : inserare la urma (ca cel mai mare element)
	if (strcmp(node->key, (*list)->prev->key) > 0) {
		curr->prev->next = node;
		node->prev = curr->prev;
		curr->prev = node;
		node->next = curr;
		return;
	}

	// 4 caz : inserare in mijloc
	while(curr->next != *list) {
		if (strcmp(node->key, curr->key) > 0){
			curr = curr->next;
		} else { break; }
	}
	
	curr->prev->next = node;
	node->prev = curr->prev;
	node->next = curr;
	curr->prev = node;
	return;
		
	
}

void put(HashTable **table, char* key, char* value) {
    // Verific daca nodul cu "key" nu a fost deja adaugat
    if (find(*table, key) == 1)
    	return;
    // Creez nodul cu <key, value>
    HTNode* node = createHTNode(key, value);
    // Calculez indexul
    unsigned long index = hashFunction(key, (*table)->size);
 	// Inserez nodul in lista la indexul calculat
    insertInList(&(*table)->lists[index], node);
}

char* get(HashTable *table, char *key) {
	// aflu indexul listei
	int index = hashFunction(key, table->size);
	HTNode *curr = table->lists[index];
	// daca lista e vida => returnez null
	if (curr == NULL)
		return "NULL";
	// parcurg lista verificand daca key apartine listei
	while(curr->next != table->lists[index]) {
		if (strcmp(curr->key, key) == 0) {
			return curr->value;
		}
		curr = curr->next;
	}
	// verificam ultimul nod
	if (strcmp(curr->key, key) == 0) {
			return curr->value;
	}
	// returnam NULL daca nu s-a gasit
	return "NULL";
}

// functia scrie elementele listei (key) in output
void printList(FILE *output, HTNode *list) {
	HTNode *curr = list;
	while(curr->next != list) {
		fprintf(output, "%s ", curr->value);
		curr = curr->next;
	}
	fprintf(output, "%s \n", curr->value);
}

// functia printeaza continutul tabelei hash in output
void print(FILE *output, HashTable* table) {
    for (int i = 0; i < table->size; i++) {
        if (table->lists[i] != NULL) {
            fprintf(output, "%d: ", i); printList(output, table->lists[i]);
        }
    }
}

// functia printeaza continutul tabelei hash in output
void printBucket(FILE *output, HashTable* table, int index) {
    if (index < table->size) {
    	if (table->lists[index] != NULL) {
        	printList(output, table->lists[index]);
        } else {
        	fprintf(output, "VIDA\n");
        }
    }
}

// Functia sterge nodul cu campul "key" din lista "list"
void removeFromList(struct HTNode** list, char* key) {
    // Daca lista e vida => nu avem ce sterge
    if (*list == NULL)
        return;
  
    // Caut nodul care trebuie sa-l elimin 
    struct HTNode *curr = *list; // nodul curent
    struct HTNode *prev = NULL; // nodul precedent
    while (strcmp(curr->key, key) != 0) {
        // Daca am ajuns la inceputul listei => nu exista asa nod in lista
        if (curr->next == *list) {
            return;
        }  
        prev = curr;
        curr = curr->next;
    }
  
    // Daca lista are un singur nod => doar eliberez memoria alocata acelui nod
    if ((curr->next == *list) && (prev == NULL)) {
        (*list) = NULL;
        free(curr->key);
		free(curr->value);
        free(curr);
        return;
    }
  	
  	/*
	Altfel am urmatoarele cazuri :
		1) Nodul e primul element al listei
		2) Nodul e intre primul si ultimul element al listei
		3) Nodul e ultimul element al listei
  	*/
// Caz 1 :    
    if (curr == *list) {
    	// leg precedentul si succesorul primului nod intre ei si elimin nodul
        prev = (*list)->prev;
        *list = (*list)->next;
        prev->next = *list;
        (*list)->prev = prev;
        free(curr->key);
		free(curr->value);
        free(curr);
        return;
    }
// Caz 2 :
    if (curr->next != *list) { // partea cu (curr != *list) am verificat-o la caz 1
        struct HTNode* tmp = curr->next;
        prev->next = tmp;
        tmp->prev = prev;
        free(curr->key);
		free(curr->value);
        free(curr);
        return;
    }
// Caz 3 :
    prev->next = *list;
    (*list)->prev = prev;
    free(curr->key);
	free(curr->value);
    free(curr);
    return;
}

// Functia sterge nodul cu "key" din tabela hash
void Remove(HashTable **table, char* key) {
    // Calculez indexul
    unsigned long index = hashFunction(key, (*table)->size);
 	// Elimin nodul din lista de la indexul calculat
    removeFromList(&(*table)->lists[index], key);
}

void freeList(HTNode *list) {
	while (list != NULL) {
		removeFromList(&list, list->key);
	}
}

void freeHashTable(HashTable *table) {
    for (int i = 0; i < table->size; i++) {
        freeList(table->lists[i]);
    }
    free(table->lists);
    free(table);
}

int main(int argc, char const *argv[]) {
	// argv[1] - M-ul
	// argv[2] - input
	// argv[3] - output

	HashTable *table = createHashTable(atoi(argv[1])); // tabela hash

	FILE *input = fopen(argv[2], "r"); // hash.in
	FILE *output = fopen(argv[3], "wr"); // hash.out

	char function[20]; // numele functiei (put/ find/ print/ remove/ get/ print_bucket)
	char url[60]; // adresa url ("www.google.com") KEY
	char ip[20]; // adresa ip ("8.8.8.8") VALUE
	int index; // indexul pentru functia print_bucket


	// atat timp cat putem citi din fisierul de intrare
	while (!feof(input)) {
		fscanf(input, "%s", function); // citim din input numele functiei
		
		// daca e functia "put"
		if (strcmp(function, "put") == 0) {
			
			// citim adresa url si adresa ip (Key si Value)
			fscanf(input, "%s", url);
			fscanf(input, "%s\n", ip);
			
			// apelam functia "put"
			put(&table, url, ip);
			
			continue; // continuam citirea datelor de intrare
		}
		// daca e functia "find"
		if (strcmp(function, "find") == 0) {
			
			// citim adresa url (Key)
			fscanf(input, "%s\n", url);
			
			// apelam functia "find"
			if (find(table, url)) {
				fprintf(output, "True\n");
			} else {
				fprintf(output, "False\n");
			}
			
			continue; // continuam citirea datelor de intrare
		}
		// daca e functia "get"
		if (strcmp(function, "get") == 0) {
			
			// citim adresa url (Key)
			fscanf(input, "%s\n", url);
			
			// apelam functia "get"
			fprintf(output, "%s\n", get(table, url));
			
			continue; // continuam citirea datelor de intrare
		}
		// daca e functia "remove"
		if (strcmp(function, "remove") == 0) {
			
			// citim adresa url (Key)
			fscanf(input, "%s\n", url);
			
			// apelam functia "remove"
			Remove(&table, url);
			
			continue; // continuam citirea datelor de intrare
		}

		// daca e functia "print"
		if (strcmp(function, "print") == 0) {
			
			// apelam functia "print"
			print(output, table);
			
			continue; // continuam citirea datelor de intrare
		}
		// daca e functia "print_bucket"
		if (strcmp(function, "print_bucket") == 0) {
			
			// citim indexult
			fscanf(input, "%d\n", &index);
			// apelam functia "print_bucket"
			printBucket(output, table, index);
		
			continue; // continuam citirea datelor de intrare
		}
	}

	freeHashTable(table);
	fclose(input);
	fclose(output);

	return 0;
}